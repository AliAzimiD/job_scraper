--
-- PostgreSQL database dump
--

-- Dumped from database version 15.12
-- Dumped by pg_dump version 15.12 (Debian 15.12-0+deb12u2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: fn_update_derived_columns(); Type: FUNCTION; Schema: public; Owner: jobuser
--

CREATE FUNCTION public.fn_update_derived_columns() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -------------------------------------------------------------------
    -- Tags logic
    -------------------------------------------------------------------
    IF NEW.tags IS NOT NULL THEN

        -- tag_no_experience
        NEW.tag_no_experience := CASE 
            WHEN EXISTS (SELECT 1 
                         FROM jsonb_array_elements_text(NEW.tags) AS t
                         WHERE t = 'بدون نیاز به سابقه')
            THEN 1
            ELSE 0
        END;
        
        -- tag_remote
        NEW.tag_remote := CASE 
            WHEN EXISTS (SELECT 1 
                         FROM jsonb_array_elements_text(NEW.tags) AS t
                         WHERE t = 'دورکاری')
            THEN 1
            ELSE 0
        END;

        -- tag_part_time
        NEW.tag_part_time := CASE 
            WHEN EXISTS (SELECT 1 
                         FROM jsonb_array_elements_text(NEW.tags) AS t
                         WHERE t = 'پاره وقت')
            THEN 1
            ELSE 0
        END;

        -- tag_internship
        NEW.tag_internship := CASE 
            WHEN EXISTS (SELECT 1 
                         FROM jsonb_array_elements_text(NEW.tags) AS t
                         WHERE t = 'کارآموزی')
            THEN 1
            ELSE 0
        END;

        -- tag_military_exemption
        NEW.tag_military_exemption := CASE 
            WHEN EXISTS (SELECT 1 
                         FROM jsonb_array_elements_text(NEW.tags) AS t
                         WHERE t = 'امریه سربازی')
            THEN 1
            ELSE 0
        END;

    END IF;

    -------------------------------------------------------------------
    -- jobBoard_titleEn & jobBoard_titleFa logic
    -------------------------------------------------------------------
    IF NEW.raw_data ? 'jobBoard' THEN
        NEW.jobBoard_titleEn := NEW.raw_data->'jobBoard'->>'titleEn';
        NEW.jobBoard_titleFa := NEW.raw_data->'jobBoard'->>'titleFa';
    END IF;

    -------------------------------------------------------------------
    -- primary_city (from locations)
    -------------------------------------------------------------------
    IF NEW.locations IS NOT NULL
       AND jsonb_typeof(NEW.locations) = 'array' THEN
        NEW.primary_city := (
            SELECT elem->'city'->>'titleEn'
            FROM jsonb_array_elements(NEW.locations) AS elem
            LIMIT 1
        );
    END IF;

    -------------------------------------------------------------------
    -- work_type (from work_types)
    -------------------------------------------------------------------
    IF NEW.work_types IS NOT NULL
       AND jsonb_typeof(NEW.work_types) = 'array' THEN
        NEW.work_type := (
            SELECT elem->>'titleEn'
            FROM jsonb_array_elements(NEW.work_types) AS elem
            LIMIT 1
        );
    END IF;

    -------------------------------------------------------------------
    -- category, parent_cat, sub_cat (from job_post_categories)
    -------------------------------------------------------------------
    IF NEW.job_post_categories IS NOT NULL
       AND jsonb_typeof(NEW.job_post_categories) = 'array'
       AND jsonb_array_length(NEW.job_post_categories) > 0 THEN

        -- If there's only one element in the array, that becomes "category"
        -- If there are at least two, the first is "parent_cat" and the second is "sub_cat" (and also "category").
        IF jsonb_array_length(NEW.job_post_categories) = 1 THEN
            NEW.category := NEW.job_post_categories->0->>'titleEn';
            NEW.parent_cat := NULL; -- or same as category if you prefer
            NEW.sub_cat := NULL;
        ELSIF jsonb_array_length(NEW.job_post_categories) >= 2 THEN
            NEW.category := NEW.job_post_categories->1->>'titleEn';
            NEW.parent_cat := NEW.job_post_categories->0->>'titleEn';
            NEW.sub_cat := NEW.job_post_categories->1->>'titleEn';
        END IF;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_update_derived_columns() OWNER TO jobuser;

--
-- Name: health_check(); Type: FUNCTION; Schema: public; Owner: jobuser
--

CREATE FUNCTION public.health_check() RETURNS text
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN 'OK';
END;
$$;


ALTER FUNCTION public.health_check() OWNER TO jobuser;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: jobuser
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                BEGIN
                    NEW.updated_at = NOW();
                    RETURN NEW;
                END;
                $$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO jobuser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: jobuser
--

CREATE TABLE public.job_batches (
    batch_id text NOT NULL,
    batch_date timestamp without time zone,
    job_count integer,
    source text,
    processing_time double precision,
    status text,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone
);


ALTER TABLE public.job_batches OWNER TO jobuser;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: jobuser
--

CREATE TABLE public.jobs (
    id text NOT NULL,
    title text,
    url text,
    locations jsonb,
    work_types jsonb,
    salary jsonb,
    gender text,
    tags jsonb,
    item_index integer,
    job_post_categories jsonb,
    company_fa_name text,
    province_match_city text,
    normalize_salary_min double precision,
    normalize_salary_max double precision,
    payment_method text,
    district text,
    company_title_fa text,
    job_board_id text,
    job_board_title_en text,
    activation_time timestamp without time zone,
    company_id text,
    company_name_fa text,
    company_name_en text,
    company_about text,
    company_url text,
    location_ids text,
    tag_number text,
    raw_data jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    batch_id text,
    batch_date timestamp without time zone,
    tag_no_experience integer DEFAULT 0,
    tag_remote integer DEFAULT 0,
    tag_part_time integer DEFAULT 0,
    tag_internship integer DEFAULT 0,
    tag_military_exemption integer DEFAULT 0,
    jobboard_titleen text,
    jobboard_titlefa text,
    primary_city text,
    work_type text,
    category text,
    parent_cat text,
    sub_cat text
);


ALTER TABLE public.jobs OWNER TO jobuser;

--
-- Name: jobs_temp; Type: TABLE; Schema: public; Owner: jobuser
--

CREATE TABLE public.jobs_temp (
    id text NOT NULL,
    title text,
    url text,
    locations jsonb,
    work_types jsonb,
    salary jsonb,
    gender text,
    tags jsonb,
    item_index integer,
    job_post_categories jsonb,
    company_fa_name text,
    province_match_city text,
    normalize_salary_min double precision,
    normalize_salary_max double precision,
    payment_method text,
    district text,
    company_title_fa text,
    job_board_id text,
    job_board_title_en text,
    activation_time timestamp without time zone,
    company_id text,
    company_name_fa text,
    company_name_en text,
    company_about text,
    company_url text,
    location_ids text,
    tag_number text,
    raw_data jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    batch_id text,
    batch_date timestamp without time zone
);


ALTER TABLE public.jobs_temp OWNER TO jobuser;

--
-- Name: scraper_stats; Type: TABLE; Schema: public; Owner: jobuser
--

CREATE TABLE public.scraper_stats (
    id integer NOT NULL,
    run_date timestamp without time zone,
    total_jobs_scraped integer,
    new_jobs_found integer,
    pages_processed integer,
    processing_time double precision,
    errors integer,
    status text,
    metadata jsonb
);


ALTER TABLE public.scraper_stats OWNER TO jobuser;

--
-- Name: scraper_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: jobuser
--

CREATE SEQUENCE public.scraper_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scraper_stats_id_seq OWNER TO jobuser;

--
-- Name: scraper_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jobuser
--

ALTER SEQUENCE public.scraper_stats_id_seq OWNED BY public.scraper_stats.id;


--
-- Name: scraper_stats id; Type: DEFAULT; Schema: public; Owner: jobuser
--

ALTER TABLE ONLY public.scraper_stats ALTER COLUMN id SET DEFAULT nextval('public.scraper_stats_id_seq'::regclass);


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: jobuser
--

COPY public.job_batches (batch_id, batch_date, job_count, source, processing_time, status, error_message, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: jobuser
--

COPY public.jobs (id, title, url, locations, work_types, salary, gender, tags, item_index, job_post_categories, company_fa_name, province_match_city, normalize_salary_min, normalize_salary_max, payment_method, district, company_title_fa, job_board_id, job_board_title_en, activation_time, company_id, company_name_fa, company_name_en, company_about, company_url, location_ids, tag_number, raw_data, created_at, updated_at, batch_id, batch_date, tag_no_experience, tag_remote, tag_part_time, tag_internship, tag_military_exemption, jobboard_titleen, jobboard_titlefa, primary_city, work_type, category, parent_cat, sub_cat) FROM stdin;
test-job-1	Test Engineer	http://example.com/job/1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-03-19 19:07:54.113047	\N	\N	Test Company	\N	\N	\N	\N	\N	2025-03-19 19:07:54.113047	2025-03-19 19:19:19.511096	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N
test-job-2	Senior Developer	http://example.com/job/2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-03-19 19:08:17.590271	\N	\N	Tech Corp	\N	\N	\N	\N	\N	2025-03-19 19:08:17.590271	2025-03-19 19:19:19.511096	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N
test-job-3	Data Scientist	http://example.com/job/3	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-03-19 19:08:17.590271	\N	\N	Analytics Inc	\N	\N	\N	\N	\N	2025-03-19 19:08:17.590271	2025-03-19 19:19:19.511096	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N
test-job-4	Python Developer	http://example.com/job/4	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-03-19 19:08:17.590271	\N	\N	Code Masters	\N	\N	\N	\N	\N	2025-03-19 19:08:17.590271	2025-03-19 19:19:19.511096	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N
test-job-5	Frontend Engineer	http://example.com/job/5	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-03-19 19:08:17.590271	\N	\N	Web Solutions	\N	\N	\N	\N	\N	2025-03-19 19:08:17.590271	2025-03-19 19:19:19.511096	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N
test-complete-job	Full Stack Developer	http://example.com/job/complete	[{"city": {"titleEn": "Tehran", "titleFa": "تهران"}}]	[{"titleEn": "Full Time", "titleFa": "تمام وقت"}]	\N	\N	["دورکاری", "پاره وقت"]	\N	[{"titleEn": "Technology", "titleFa": "تکنولوژی"}, {"titleEn": "Software Development", "titleFa": "توسعه نرم افزار"}]	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-03-19 19:19:32.361473	\N	\N	Tech Company	\N	\N	\N	\N	{"jobBoard": {"titleEn": "Example Job Board", "titleFa": "بورد نمونه"}}	2025-03-19 19:19:32.361473	2025-03-19 19:19:32.361473	\N	\N	0	1	1	0	0	Example Job Board	بورد نمونه	Tehran	Full Time	Software Development	Technology	Software Development
\.


--
-- Data for Name: jobs_temp; Type: TABLE DATA; Schema: public; Owner: jobuser
--

COPY public.jobs_temp (id, title, url, locations, work_types, salary, gender, tags, item_index, job_post_categories, company_fa_name, province_match_city, normalize_salary_min, normalize_salary_max, payment_method, district, company_title_fa, job_board_id, job_board_title_en, activation_time, company_id, company_name_fa, company_name_en, company_about, company_url, location_ids, tag_number, raw_data, created_at, updated_at, batch_id, batch_date) FROM stdin;
\.


--
-- Data for Name: scraper_stats; Type: TABLE DATA; Schema: public; Owner: jobuser
--

COPY public.scraper_stats (id, run_date, total_jobs_scraped, new_jobs_found, pages_processed, processing_time, errors, status, metadata) FROM stdin;
\.


--
-- Name: scraper_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jobuser
--

SELECT pg_catalog.setval('public.scraper_stats_id_seq', 1, false);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: jobuser
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (batch_id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: jobuser
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: scraper_stats scraper_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: jobuser
--

ALTER TABLE ONLY public.scraper_stats
    ADD CONSTRAINT scraper_stats_pkey PRIMARY KEY (id);


--
-- Name: idx_jobs_activation_time; Type: INDEX; Schema: public; Owner: jobuser
--

CREATE INDEX idx_jobs_activation_time ON public.jobs USING btree (activation_time);


--
-- Name: idx_jobs_batch_id; Type: INDEX; Schema: public; Owner: jobuser
--

CREATE INDEX idx_jobs_batch_id ON public.jobs USING btree (batch_id);


--
-- Name: idx_jobs_company_id; Type: INDEX; Schema: public; Owner: jobuser
--

CREATE INDEX idx_jobs_company_id ON public.jobs USING btree (company_id) WHERE (company_id IS NOT NULL);


--
-- Name: jobs trg_update_derived_columns; Type: TRIGGER; Schema: public; Owner: jobuser
--

CREATE TRIGGER trg_update_derived_columns BEFORE INSERT OR UPDATE ON public.jobs FOR EACH ROW EXECUTE FUNCTION public.fn_update_derived_columns();


--
-- Name: jobs update_jobs_updated_at; Type: TRIGGER; Schema: public; Owner: jobuser
--

CREATE TRIGGER update_jobs_updated_at BEFORE UPDATE ON public.jobs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: jobuser
--

ALTER DEFAULT PRIVILEGES FOR ROLE jobuser IN SCHEMA public GRANT SELECT,USAGE ON SEQUENCES  TO jobuser;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: jobuser
--

ALTER DEFAULT PRIVILEGES FOR ROLE jobuser IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES  TO jobuser;


--
-- PostgreSQL database dump complete
--

